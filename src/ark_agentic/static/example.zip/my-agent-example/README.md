# my-agent-example

基于 ark-agentic 的最小示例（API + 内置 Web Chat UI）。

## 运行

```bash
uv pip install -e .
# 编辑 .env 填入 API_KEY
python -m my_agent_example.app
```

打开 <http://localhost:8080> 即可使用 Chat UI。
