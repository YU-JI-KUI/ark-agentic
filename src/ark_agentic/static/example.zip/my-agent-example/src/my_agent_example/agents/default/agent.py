"""
Default 智能体

环境变量:
    SESSIONS_DIR: 会话持久化基础目录（默认 data/ark_sessions）
    MEMORY_DIR:   Memory 数据基础目录（默认 data/ark_memory）
"""

from __future__ import annotations

from pathlib import Path

from langchain_core.language_models.chat_models import BaseChatModel

from ark_agentic import AgentDef, AgentRunner, build_standard_agent
from ark_agentic.core.callbacks import RunnerCallbacks

from .tools import create_default_tools

_AGENT_DIR = Path(__file__).resolve().parent

_DEF = AgentDef(
    agent_id="default",
    agent_name="Default",
    agent_description="TODO: 描述你的智能体功能",
)


def create_default_agent(
    llm: BaseChatModel | None = None,
    *,
    enable_memory: bool = False,
    enable_dream: bool = True,
    callbacks: RunnerCallbacks | None = None,
) -> AgentRunner:
    """创建 Default 智能体。

    Args:
        llm: LLM 实例；None 时从环境变量初始化
        enable_memory: 是否启用 Memory 系统
        enable_dream: 是否启用后台记忆蒸馏（需 enable_memory=True 才有效）
        callbacks: 业务回调（鉴权、上下文注入、引用校验等）
    """
    return build_standard_agent(
        _DEF,
        skills_dir=_AGENT_DIR / "skills",
        tools=create_default_tools(),
        llm=llm,
        enable_memory=enable_memory,
        enable_dream=enable_dream,
        callbacks=callbacks,
    )
