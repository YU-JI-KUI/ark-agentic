"""
Default - 工具模块

在此定义和注册业务工具。
"""

from __future__ import annotations

from ark_agentic.core.tools import AgentTool


def create_default_tools() -> list[AgentTool]:
    """返回 Default 智能体使用的业务工具列表。

    在此处实例化你的工具并加入返回列表。
    """
    return []
