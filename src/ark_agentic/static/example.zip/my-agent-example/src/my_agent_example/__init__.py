"""
Default 智能体模块
"""

from .agent import create_default_agent

__all__ = ["create_default_agent"]
